#！/bin/bash
if test -z "$(lsof -i:8080)";then
	nohup java -jar /opt/kvm/kvm.jar > /opt/kvm/log/kvm.log 2>&1 &
	echo -e  "\033[32m服务启动成功！ \033[0m" 
else
	echo -e "\033[32m服务处于运行状态！ \033[0m" 
fi
