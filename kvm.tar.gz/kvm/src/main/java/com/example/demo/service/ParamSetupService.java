package com.example.demo.service;

import java.util.List;

import com.example.demo.empty.ParamSetup;

public interface ParamSetupService {
	
	public List<ParamSetup> allSelectLists(ParamSetup param);

}
