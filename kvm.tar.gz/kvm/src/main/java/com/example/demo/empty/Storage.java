package com.example.demo.empty;


public class Storage {
	
	private Integer storageId;
	
	public Integer getStorageId() {
		return storageId;
	}

	public void setStorageId(Integer storageId) {
		this.storageId = storageId;
	}

	public Integer getStorageType() {
		return storageType;
	}

	public void setStorageType(Integer storageType) {
		this.storageType = storageType;
	}

	public String getStoragePath() {
		return storagePath;
	}

	public void setStoragePath(String storagePath) {
		this.storagePath = storagePath;
	}

	public String getLocalPath() {
		return localPath;
	}

	public void setLocalPath(String localPath) {
		this.localPath = localPath;
	}

	public String getStorageUsername() {
		return storageUsername;
	}

	public void setStorageUsername(String storageUsername) {
		this.storageUsername = storageUsername;
	}

	public String getStoragePassword() {
		return storagePassword;
	}

	public void setStoragePassword(String storagePassword) {
		this.storagePassword = storagePassword;
	}

	public Integer getStorageStatu() {
		return storageStatu;
	}

	public void setStorageStatu(Integer storageStatu) {
		this.storageStatu = storageStatu;
	}

	private Integer storageType;
	
	private String storagePath;
	
	private String localPath;
	
	private String storageUsername;
	
	private String storagePassword;
	
	private Integer storageStatu;
	

}
