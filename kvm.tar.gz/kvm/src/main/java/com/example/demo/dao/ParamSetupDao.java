package com.example.demo.dao;

import java.util.List;

import com.example.demo.empty.ParamSetup;

public interface ParamSetupDao {
	
	public List<ParamSetup> allSelectLists(ParamSetup param);

}
