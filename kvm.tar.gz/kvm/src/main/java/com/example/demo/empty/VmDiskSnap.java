package com.example.demo.empty;

public class VmDiskSnap {
	  private String id;
	  
	  private String tag;
	  
	  private String vmsize;
	  
	  private String date;
	  
	  private String vmclock;
	  
	  public String getId() {
	    return this.id;
	  }
	  
	  public void setId(String id) {
	    this.id = id;
	  }
	  
	  public String getTag() {
	    return this.tag;
	  }
	  
	  public void setTag(String tag) {
	    this.tag = tag;
	  }
	  
	  public String getVmsize() {
	    return this.vmsize;
	  }
	  
	  public void setVmsize(String vmsize) {
	    this.vmsize = vmsize;
	  }
	  
	  public String getDate() {
	    return this.date;
	  }
	  
	  public void setDate(String date) {
	    this.date = date;
	  }
	  
	  public String getVmclock() {
	    return this.vmclock;
	  }
	  
	  public void setVmclock(String vmclock) {
	    this.vmclock = vmclock;
	  }
}