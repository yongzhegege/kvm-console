{
  "code": 0
  ,"msg": ""
  ,"data": {
    "list": [{
      "username": "测试1"
      ,"id": "100001"
      ,"avatar": ""
      ,"sign": "测试内容"
    },{
      "username": "测试6"
      ,"id": "121286"
      ,"avatar": ""
      ,"sign": "测试内容"
    },{
      "username": "测试8"
      ,"id": "12123454"
      ,"avatar": ""
      ,"sign": ""
    }]
  }
}