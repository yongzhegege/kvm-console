if test -z "$(lsof -i:8080)";then
        echo -e "\033[31m服务不处于运行状态！\033[0m"
else
	lsof -i:8080|grep -v "PID"|awk '{print "kill -9",$2}'|sh;
	lsof -i:5080|grep -v "PID"|awk '{print "kill -9",$2}'|sh;
	echo -e "\033[32m服务已停止！\033[0m"
fi  	
